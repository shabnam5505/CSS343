//Shabnam Basmani
//This is an abstract class created so that objects that wish to use the BST class can inherit from this class. 
#include "TreeData.h"

//default constructor will not be used because this is an abstract class
//no pre or post conditions
TreeData::TreeData()
{
}


//virtual destructor will not be used because this is an abstract class
//no pre or post conditions
TreeData::~TreeData()
{
}
